package com.careconnectapi.api.service;

import com.careconnectapi.api.entity.AppointmentEntity;
import com.careconnectapi.api.model.AppointmentRequestBody;
import com.careconnectapi.api.model.PractitionerIdRequest;
import com.careconnectapi.api.repositories.AppointmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AppointmentService {

    @Autowired
    private AppointmentRepository appointmentRepository;

    // Create a new appointment
    public AppointmentEntity createAppointment(AppointmentRequestBody appointmentRequestBody) {
        AppointmentEntity newAppointment = new AppointmentEntity();
        newAppointment.setDoctorId(appointmentRequestBody.getDoctorId());
        newAppointment.setFirstName(appointmentRequestBody.getFirstName());
        newAppointment.setLastName(appointmentRequestBody.getLastName());
        newAppointment.setSpecialty(appointmentRequestBody.getSpecialty());
        newAppointment.setPhoneNumber(appointmentRequestBody.getPhoneNumber());
        newAppointment.setEmailId(appointmentRequestBody.getEmailId());
        newAppointment.setYearsOfExperience(appointmentRequestBody.getYearsOfExperience());
        newAppointment.setHospitalId(appointmentRequestBody.getHospitalId());
        return appointmentRepository.save(newAppointment);
    }

    // Update an existing appointment
    public AppointmentEntity updateAppointment(int appointmentId, AppointmentRequestBody appointmentRequestBody) {
        Optional<AppointmentEntity> existingAppointmentOpt = appointmentRepository.findById(appointmentId);
        
        if (!existingAppointmentOpt.isPresent()) {
            throw new RuntimeException("Appointment not found");
        }

        AppointmentEntity existingAppointment = existingAppointmentOpt.get();
        existingAppointment.setDoctorId(appointmentRequestBody.getDoctorId());
        existingAppointment.setFirstName(appointmentRequestBody.getFirstName());
        existingAppointment.setLastName(appointmentRequestBody.getLastName());
        existingAppointment.setSpecialty(appointmentRequestBody.getSpecialty());
        existingAppointment.setPhoneNumber(appointmentRequestBody.getPhoneNumber());
        existingAppointment.setEmailId(appointmentRequestBody.getEmailId());
        existingAppointment.setYearsOfExperience(appointmentRequestBody.getYearsOfExperience());
        existingAppointment.setHospitalId(appointmentRequestBody.getHospitalId());

        return appointmentRepository.save(existingAppointment);
    }

    // List all appointments with pagination
    public Page<AppointmentEntity> listAllAppointments(int pageNumber, int size) {
        Pageable pageable = PageRequest.of(pageNumber, size);
        return appointmentRepository.findAllAppointments(pageable);
    }

    // Delete an appointment
    public String deleteAppointment(int appointmentId) {
        appointmentRepository.deleteById(appointmentId);
        return "Appointment Deleted";
    }

    // Count total number of appointments
    public long countNumberOfAppointments() {
        return appointmentRepository.count();
    }
}