package com.careconnectapi.api.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class appointmentRequest {
	private int empId;

	

}
