package com.careconnectapi.api.model;

public class PractitionerIdRequest {
	private int empId;

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

}
