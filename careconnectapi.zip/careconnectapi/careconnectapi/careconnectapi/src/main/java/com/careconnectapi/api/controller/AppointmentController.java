package com.careconnectapi.api.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.careconnectapi.api.service.AppointmentService;
import com.careconnectapi.api.service.PractitionerService;
import com.careconnectapi.api.model.AppointmentRequestBody;

@RestController
@CrossOrigin
@RequestMapping("/appointment")
public class AppointmentController {
    
    @Autowired
    private AppointmentService appointmentService;
   	

    @PostMapping("/create")
    public ResponseEntity<?> createAppointment(@RequestBody AppointmentRequestBody appointmentRequestBody) throws Exception {
        return ResponseEntity.ok(appointmentService.createAppointment(appointmentRequestBody));
    }

    @PutMapping("/update")
    public ResponseEntity<?> updateAppointment(@RequestBody int appointmentId, AppointmentRequestBody appointmentRequestBody) throws Exception {
        return ResponseEntity.ok(appointmentService.updateAppointment(appointmentId, appointmentRequestBody));
    }

    @GetMapping("/list")
    public ResponseEntity<?> listAllAppointments(@RequestParam(defaultValue = "0") final Integer pageNumber,
                                                 @RequestParam(defaultValue = "10") final Integer size) throws Exception {
        return ResponseEntity.ok(appointmentService.listAllAppointments(pageNumber, size));
    }

    @DeleteMapping("/delete/{appointmentId}")
    public ResponseEntity<?> deleteAppointment(@PathVariable int appointmentId) throws Exception {
        return ResponseEntity.ok(appointmentService.deleteAppointment(appointmentId));
    }

    @GetMapping("/count")
    public ResponseEntity<?> countNumberOfAppointments() throws Exception {
        return ResponseEntity.ok(appointmentService.countNumberOfAppointments());
    }
}