package com.careconnectapi.api.repositories;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.careconnectapi.api.entity.AppointmentEntity;

@Repository
public interface AppointmentRepository extends CrudRepository<AppointmentEntity, Integer> {

    @Query(value = "SELECT * FROM vidya_appointment", nativeQuery = true)
    Page<AppointmentEntity> findAllAppointments(Pageable pageable);

    @Query(value = "SELECT COUNT(*) FROM vidya_appointment", nativeQuery = true)
    long countNumberOfAppointments(); // Changed return type to long
}